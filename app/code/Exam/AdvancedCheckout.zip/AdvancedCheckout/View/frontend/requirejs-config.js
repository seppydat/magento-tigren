var config = {
    map: {
        '*': {
            'advanced': 'Exam_AdvancedCheckout/js/AdvancedCheckout'
        }
    }
};
