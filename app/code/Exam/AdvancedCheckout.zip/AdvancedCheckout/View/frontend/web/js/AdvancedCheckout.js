require(['jquery',
    'Magento_Ui/js/modal/modal',
    'mage/url'
], function($, modal, urlBuilder){
    var options = {
        type: 'popup',
        responsive: true,
        innerScroll: true,
        title: 'Pop-up title',
        buttons: [{
            text: $.mage.__('Close'),
            class: 'modal-close',
            click: function (){
                this.closeModal();
            }
        }]
    };
    modal(options, $('#modal-content'));

    $('#product-addtocart-button').on('click', function () {
       var id_product = $('input[name="product"]').val();
       var countItem = parseInt($('span.counter-number').text());

       console.log(getMultiAllow(id_product));
       // if (getMultiAllow(id_product)) {
       //     return true;
       // } else {
       //     if (!countItem) {
       //         return true;
       //     } else {
       //         $("#modal-content").modal("openModal");
       //         return false;
       //     }
       // }
    });

    $('#go-to-checkout').on('click', function () {
        window.location.href = urlBuilder.build('checkout');
    });

    $('#clear-cart').on('click', function () {
        window.location.href = urlBuilder.build('advanced_front/advanced/ClearCart');
    });
    function getMultiAllow (id_product) {
        var check;
        var url = urlBuilder.build('advanced_front/advanced/CheckMultiAllow');
        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'text',
            data: {
                id_item: id_product
            }
        }).done( function (result) {
            // console.log(result);
            check = result;
        });

        return check;
    }
});

