<?php

namespace Exam\AdvancedCheckout\Controller\Advanced;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use \Magento\Quote\Model\Quote\Item;

class CheckMultiAllow extends  Action{

    protected $_session;

    protected $_quoteItem;

    function __construct(
        Context $context,
        Session $session,
        Item $quoteItem
    )
    {
        $this->_quoteItem = $quoteItem;
        $this->_session = $session;
        parent::__construct($context);
    }

    public function execute()
    {
        $postValue = $this->getRequest()->getPostValue();
        $id_product = $postValue['id_item'];
            echo "true";
    }
}
