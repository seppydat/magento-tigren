<?php

namespace Exam\AdvancedCheckout\Controller\Advanced;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use \Magento\Quote\Model\Quote\Item;

class ClearCart extends  Action{

    protected $_session;

    protected $_quoteItem;

    function __construct(
        Context $context,
        Session $session,
        Item $quoteItem
    )
    {
        $this->_quoteItem = $quoteItem;
        $this->_session = $session;
        parent::__construct($context);
    }

    public function execute()
    {
        $allItems = $this->_session->getQuote()->getAllVisibleItems();

        $error = 0;
        foreach ($allItems as $item) {
            $itemId = $item->getItemId();//item id of particular item
            $allItems = $this->_quoteItem->load($itemId);
            try {
                $allItems->delete();
            } catch (\Exception $e) {
                $error++;
            }
        }

        $this->_redirect('/');
    }
}
